﻿using System;
using System.Diagnostics; // Add this for Process class
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using CloudyApi;
using Microsoft.Win32;

namespace Phantom_v2
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ApplyTheme("Dark"); // Default theme on launch

            // Begin Sidebar slide-in animation on load
            Loaded += (s, e) =>
            {
                var storyboard = Resources["SidebarSlideIn"] as Storyboard;
                storyboard?.Begin(SidebarPanel);
            };
            ShowSection(HomeSection); // Start with Home section


        }

        // Header Dragging
        private void HeaderBorder_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                this.DragMove();
            }
        }

        // Navigation Handlers
        private void HomeButton_Click(object sender, RoutedEventArgs e) => ShowSection(HomeSection);
        private void ScriptHubButton_Click(object sender, RoutedEventArgs e) => ShowSection(ScriptHubSection);
        private void SettingsButton_Click(object sender, RoutedEventArgs e) => ShowSection(SettingsSection);

        // Discord Join Handlers
        private void JoinMainDiscord_Click(object sender, RoutedEventArgs e)
        {
            OpenDiscordLink("https://discord.gg/yh4TdgAgej"); // Replace with your actual link
        }

        private void JoinSupportDiscord_Click(object sender, RoutedEventArgs e)
        {
            OpenDiscordLink("https://discord.gg/4bT2jkaf5e"); // Replace with your actual link
        }

        private void OpenDiscordLink(string url)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                });
            }
            catch
            {
                MessageBox.Show("Failed to open link.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Script execution handlers


        // Show section with fade-in animation
        private void ShowSection(UIElement section)
        {
            HomeSection.Visibility = Visibility.Collapsed;
            ScriptHubSection.Visibility = Visibility.Collapsed;
            SettingsSection.Visibility = Visibility.Collapsed;

            section.Visibility = Visibility.Visible;

            // Apply fade-in animation with casting to FrameworkElement
            if (section is FrameworkElement frameworkElement)
            {
                var fadeInStoryboard = Resources["FadeIn"] as Storyboard;
                fadeInStoryboard?.Begin(frameworkElement);
            }
        }

        // Minimize and Close window methods
        private void Minimize_Click(object sender, RoutedEventArgs e) => this.WindowState = WindowState.Minimized;
        private void Close_Click(object sender, RoutedEventArgs e) => this.Close();

        // Theme selection changed
        private void ThemeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ThemeComboBox.SelectedItem is ComboBoxItem selectedTheme)
            {
                ApplyTheme(selectedTheme.Content.ToString());
            }
        }

        // Font size selection changed
        private void FontSizeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FontSizeComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                // Get the font size from the Tag property
                double newSize = (double)selectedItem.Tag;

                // Update the font size of relevant UI elements

                // Adjust other text elements here as necessary
            }
        }

        // Save settings method
        private void SaveSettings_Click(object sender, RoutedEventArgs e)
        {
            string selectedTheme = (ThemeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            MessageBox.Show("Settings saved. Selected theme: " + selectedTheme, "Settings", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // Apply theme method
        private void ApplyTheme(string theme)
        {
            var darkBackground = (System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFrom("#1e1e1e");
            var lightBackground = System.Windows.Media.Brushes.White;
            var lightSidebar = System.Windows.Media.Brushes.LightGray;

            MainGrid.Background = theme == "Dark" ? darkBackground : lightBackground;
            SidebarPanel.Background = theme == "Dark" ? (System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFrom("#2d2d2d") : lightSidebar;
            HeaderBorder.Background = (System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFrom("#333333");

            foreach (Button button in SidebarPanel.Children)
            {
                button.Background = theme == "Dark" ? (System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFrom("#555555") : System.Windows.Media.Brushes.Gainsboro;
                button.Foreground = theme == "Dark" ? System.Windows.Media.Brushes.White : System.Windows.Media.Brushes.Black;
            }

            MessageBox.Show("Theme changed to: " + theme, "Theme Change", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
