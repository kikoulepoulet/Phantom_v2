﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;
using CloudyApi;
using System;
using Microsoft.Win32;
using System.IO;

namespace Phantom_v2
{
    public partial class ScriptHub : UserControl
    {
        // This will hold all scripts for search and history purposes
        private List<string> allScripts = new List<string>();

        public ScriptHub()
        {
            InitializeComponent();
        }

        // Load initial sample scripts when control is loaded
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            AddToHistory("print('Hello, World!')");
            AddToHistory("game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 50");
            AddToHistory("loadstring(game:HttpGet('https://example.com/script.lua'))()");
        }

        // Execute button click event handler
        private void Execute_Click(object sender, RoutedEventArgs e)
        {
            Api.execute(ScriptEditor.Text);
            string scriptText = ScriptEditor.Text;

            if (string.IsNullOrWhiteSpace(scriptText))
            {
                LogToConsole("Error: No script to execute.");
                return;
            }

            AddToHistory(scriptText); // Add script to history when executed

            LogToConsole("Executing script...");
            // Simulate script execution
            LogToConsole($"Script executed: {scriptText}");
        }

        // Clear button click event handler
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            ScriptEditor.Clear();
            LogToConsole("Editor cleared.");
        }

        // Save button click event handler
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                File.WriteAllText(saveFileDialog.FileName, ScriptEditor.Text);
                LogToConsole("Script saved");
            }
        }

        // Open button click event handler
        private void Open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string fileContent = File.ReadAllText(openFileDialog.FileName);
                ScriptEditor.Text = fileContent;
                LogToConsole("Script opened");
            }
        }

        // Inject button click event handler
        private void Inject_Click(object sender, RoutedEventArgs e)
        {
            Api.inject();
            LogToConsole("Injecting script...");
            // Simulate script injection logic
            LogToConsole("Script injection completed.");
        }

        // ScriptHistory selection changed event handler
        private void ScriptHistory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ScriptHistory.SelectedItem != null)
            {
                ScriptEditor.Text = ScriptHistory.SelectedItem.ToString();
                LogToConsole($"Script loaded: {ScriptHistory.SelectedItem}");
            }
        }

        // Helper method to add scripts to history
        private void AddToHistory(string script)
        {
            allScripts.Add(script);
            ScriptHistory.Items.Add(script); // Add to ListBox for display
            LogToConsole($"Script added to history: {script}");
        }

        // Helper method to log messages to the ConsoleOutput
        private void LogToConsole(string message)
        {
            ConsoleOutput.AppendText($"{message}\n");
            ConsoleOutput.ScrollToEnd(); // Ensure the latest message is visible
        }
    }
}
